package p352_2;
import java.util.*;
public class stack <E> implements STK<E>{
    ArrayList<E> ary = new ArrayList<>();

    public void push(E obj) {
        ary.add(obj);
    }

    public E pop() {
        if(!ary.isEmpty()){
            return ary.remove(ary.size()-1);
        }
        else
        return null;
    }

    public E top() {
        if(!ary.isEmpty()){
        return ary.get(ary.size()-1);}
        else
        return null;
    }

    public int size() {
        return ary.size();
    }

    public boolean isEmpty() {
        if(!ary.isEmpty()){
            return false;
        }
        else
        return true;
    }
}
