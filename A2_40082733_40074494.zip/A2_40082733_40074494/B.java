// -----------------------------------------------------------------------------
// Written by: WEI YUAN student ID : 40074494 & Zilin Xu student ID : 40082733
// -----------------------------------------------------------------------------
package p352_2;
import java.io.*;
import java.util.*;
public class B {

    public static void main(String[] b) throws IOException {

        Scanner scanner = new Scanner(new File("java B in.txt"));
        PrintStream out = new PrintStream(new FileOutputStream("java B out.txt"));
        System.setOut(out);
        String total = scanner.next();
        int t = Integer.parseInt(total);
        for (int i = 0; i < t; i++) {

            String lenght = scanner.next();
            int l = Integer.parseInt(lenght);
            String s[] = new String[l];
            for (int j = 0; j < l; j++) {
                s[j] = scanner.next();
            }
            int start = Integer.parseInt(s[0]);
            int[] A = new int[s.length];
            for (int k = 1; k < s.length; k++) {
                A[k - 1] = Integer.parseInt(s[k]);
            }

            try {
                System.out.println(Bstack(A, start));
            } catch (NullPointerException e) {
                System.out.println("0");
            }
        }
    }

    static int Bstack(int ary[], int i) throws NullPointerException {
        int length = ary.length - 1;
        int left, right;
        boolean finish = true;
        int[] a = new int[ary.length];
        stack<Integer> s = new stack<Integer>();

        if (i==length||ary[i]==0) return 1;
        if (i > length || i < 0) return 0;
        else {
            while (finish) {
                if (a[i]==0) {
                    a[i]++;//remember position where I'm if I were never been here yet
                    //System.out.println("p= " + p);
                    left = i - ary[i];//find the left position from the position where I'm
                    right = i + ary[i];//find the right position from the position where I'm let always the right above the left in stack, because 0 is in right,so right direction has priority
                    if (left >= 0) s.push(left); //remember from this position to left
                    if (right <= length) s.push(right); //remember from this position to right
                }
                if (!s.isEmpty()) {
                    if (s.top() == length) return 1;
                    i = s.pop(); //i is not the exit position so let's continue to the while loop
                } else finish = false; //with 2 ways I don't get exit
            }
            return 0;
        }
    }
}