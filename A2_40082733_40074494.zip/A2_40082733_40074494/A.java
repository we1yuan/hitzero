// -----------------------------------------------------------------------------
// Written by: WEI YUAN student ID : 40074494 & Zilin Xu student ID : 40082733
// -----------------------------------------------------------------------------
package p352_2;
import java.io.*;
import java.util.*;
public class A {

    public static void main(String[] a)throws IOException{

        Scanner scanner = new Scanner(new File("java A in.txt"));
        //FileReader rd=new FileReader("java A in.txt");
        PrintStream out = new PrintStream(new FileOutputStream("java A out.txt"));
        System.setOut(out);
        String total=scanner.next();
        int t = Integer.parseInt(total);
       // System.out.println(t);
        for(int i=0;i<t;i++) {

                String lenght = scanner.next();
                int l = Integer.parseInt(lenght);
                String s[]=new String [l];
                for(int j=0;j<l;j++)
                {
                    s[j]=scanner.next();
                    /*System.out.print(s[j]+" ");*/
                }
                int start=Integer.parseInt(s[0]);
                /*System.out.println(start);*/
                int[] xa=new int [s.length];
                for(int k=1;k<s.length;k++) {
                    xa[k - 1] = Integer.parseInt(s[k]);
                }
                /*for(int n=0;n<xa.length;n++) {
                    System.out.print(xa[n] + " ");
                }*/
                /*System.out.println();*/
                int[] xb= new int[xa.length];
                /*for(int n=0;n<xa.length;n++) {
                    System.out.print(xb[n] + " ");
                }*/

        /*System.out.println();*/
        try{
            System.out.println(Arecursive(xa,start,xa[start],xb,5));
        }
        catch(IndexOutOfBoundsException e){
            System.out.println("0");
        }

        }
    }

    static int Arecursive(int[] a,int i,int j,int[] b,int d)throws IndexOutOfBoundsException{
        int l = a.length-1;
        if(j==0||i==l) return 1;
        //if (i > l || i < 0) return 0;
        else{
           if(i+j>l||i-j>=0) d=1;  //1 means left 0 means right
            else if(i-j<0||i+j<=l) d=0;
            else return 0;

                if(b[i]==1) //last position where I have been after get a loop
                    d=changeDirection(d);
                if(b[i]!=1&&b[i]!=0) //against same position that's mean no solution
                    return 0;
            b[i]++;  //remember position with that

            if((d==0)&&i+j<=l) return Arecursive(a,i+j,a[i+j],b,d);
            else if((d==1)&&i-j>=0) return Arecursive(a,i-j,a[i-j],b,d);
            else return 0;

        }
    }

    static int changeDirection(int oi){
        if(oi==0)
            return 1;
        else if(oi==1)
            return 0;
        else
            throw new ArithmeticException();
    }
}
