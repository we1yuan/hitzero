package p352_2;

public interface STK <E> {

    void push(E obj);

    E pop();

    E top();

    int size();

    boolean isEmpty();

}
